import React from 'react';
import {Text, View, Image, StyleSheet} from 'react-native';
const Yourapp = () =>{
  return(
    <View style={style.container}>
    <Image source={{uri:"https://picsum.photos/200"}}  style={{height:100,width:100}}/>
    </View>
  );
};
const style = StyleSheet.create({
  container:{
    flex:1,backgroundColor:'orange',
    justifyContent:'center'
  }
})

export default Yourapp;