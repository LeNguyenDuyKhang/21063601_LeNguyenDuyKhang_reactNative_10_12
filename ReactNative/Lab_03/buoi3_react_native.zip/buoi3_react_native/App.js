import React from 'react';
import AppNavigator from './AppNavigator';

// You can import supported modules from npm

export default function App() {
  return <AppNavigator />;
}



// import { Text, SafeAreaView, StyleSheet,Button, View ,Image} from 'react-native';

// import {Ionicons} from '@expo/vector-icons'

// import * as React from 'react';

// import { NavigationContainer } from '@react-navigation/native';
// import { createNativeStackNavigator } from '@react-navigation/native-stack';

// // You can import supported modules from npm
// import { Card } from 'react-native-paper';

// // or any files within the Snack
// import AssetExample from './components/AssetExample';

// export default function HomeScreen({navigation}){
//   return(
//     <View style={{flex:1}}>
//       <View style={styles.container}>
//         <Image style={styles.logo} source ={require('./assets/MauXanh.jpg')}/>
//         <Text>Điện Thoại Vsmart Joy 3 - Hàng chính hãng</Text>
//       </View>
      
//       <View style={{flex:1, flexDirection:'row', justifyContent:'center',marginTop:-20}}>
//         <View style={{flexDirection:'row',}}>
//           <Ionicons name="star" size={32} color="#E0E41A" />
//           <Ionicons name="star" size={32} color="#E0E41A" />
//           <Ionicons name="star" size={32} color="#E0E41A" />
//           <Ionicons name="star" size={32} color="#E0E41A" />
//           <Ionicons name="star" size={32} color="#E0E41A" />
//         </View>
//         <View style={{marginTop:9,marginLeft:5}}>
//           <Text>(Xem 828 danh gia)</Text>
//         </View>
//       </View>
//       <View style={styles.container}>
//         <Text style={{}}>1.790.000 d
//         </Text>
//       </View>
//     </View>
    
//   );

// }

// const styles = StyleSheet.create({
//   container: {
    
//     alignItems: 'center',
//     justifyContent: 'center',
//     padding: 30,
//   },
//   paragraph: {
//     margin: 24,
//     marginTop: 0,
//     fontSize: 14,
//     fontWeight: 'bold',
//     textAlign: 'center',
//   },
//   logo: {
    
//     height: 250,
//     width: 200,
    
//   },
//   star: {
//     position: 'absolute',
//     width: 23,
//     height: 25,
//     left: 22,
//     top: 382,
//     background: '#E0E41A'
//   }
// });



