import React from 'react';
import AppNavigator from './AppNavigator';

// You can import supported modules from npm

export default function App() {
  return <AppNavigator />;
}

