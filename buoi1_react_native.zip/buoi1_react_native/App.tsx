import React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';



const yourapp =() =>{
  return(
    <View style={style.container}>
      <Image source={{uri:'https://picsum.photos/200'}} style={{height:100, width:100}} />
    </View>
  )
}

const style = StyleSheet.create({
  container: {
    flex: 1, backgroundColor:'violet',
    justifyContent:'center',
    alignItems: 'center'
  }
})
export default yourapp;